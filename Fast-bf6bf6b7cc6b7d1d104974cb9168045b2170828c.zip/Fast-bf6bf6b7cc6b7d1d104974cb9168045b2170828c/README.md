<h1 align="center">FAST</h1>
<p align="center">Fastest script to clone random Facebook accounts from public identity without login also without checkpoint</p>




## ***Installation***


* Telegram : [Follow Me](https://t.me/TT_RQ)


* Facebook : [Follow Me](https://www.facebook.com/118462356860246)


### Warning


***If You Wanna Take Credits For This Code, Please Look Yourself Again...

### Screenshot
![FAST1](https://raw.githubusercontent.com/SidraELEzz/Fast/main/FAST1.png)




